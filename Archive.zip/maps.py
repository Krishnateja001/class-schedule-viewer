from flask import Flask, request, render_template
from flask_sqlalchemy import SQLAlchemy
from urllib.parse import quote
app = Flask(__name__)

# Encode the password
encoded_password = quote("groot@123", safe='')

# Configure MySQL database connection
app.config['SQLALCHEMY_DATABASE_URI'] = f'mysql+pymysql://root:{encoded_password}@localhost/Lewis_schedule'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
Session = sessionmaker(bind=engine)
@app.route('/')
def index():
    return render_template('lewis_map.html')

@app.route('/schedule', methods=['POST'])
def show_schedule():
    campus = request.form['campus']
    instructor = request.form['instructor']
    start_date = request.form['start_date']
    end_date = request.form['end_date']
    session = Session()
    # Connect to the database

    query = select([course_table]).where(
        course_table.c.campus == campus,
        course_table.c.instructors == instructor,
        course_table.c.start_date >= start_date,
        course_table.c.end_date <= end_date
    )
    # Query to fetch class schedules based on filters
    query = """
        SELECT * FROM course
        WHERE campus = %s
        AND instructors = %s
        AND start_date >= %s
        AND end_date <= %s
    """

    result=db.session.execute(query)
    schedules = result.fetchall()



    # Render template with schedules
    return render_template('schedule.html', schedules=schedules)

if __name__ == '__main__':
    app.run(debug=True)